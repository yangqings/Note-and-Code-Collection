import React from 'react'
import 'antd/dist/antd.css';

export default class TempStatusCard extends React.Component {
    render() {
        return (
            <div>
               这是引入TempStatusCard组件后的内容
            </div>
        );
    }
}
