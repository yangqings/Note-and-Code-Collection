import React from 'react'
import 'antd/dist/antd.css';

export default class HistoricalChart extends React.Component {
    render() {
        return (
            <div>
               这是引入HistoricalChart组件后的内容
            </div>
        );
    }
}
