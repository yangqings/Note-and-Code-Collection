import React from 'react'
import 'antd/dist/antd.css';

export default class HistoricalAlarmTable extends React.Component {
    render() {
        return (
            <div>
               这是引入HistoricalAlarmTable组件后的内容
            </div>
        );
    }
}
