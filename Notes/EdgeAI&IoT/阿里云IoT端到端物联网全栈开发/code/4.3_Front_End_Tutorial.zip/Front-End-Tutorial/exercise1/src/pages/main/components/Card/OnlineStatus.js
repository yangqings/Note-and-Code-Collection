import React from 'react'
import 'antd/dist/antd.css';

export default class OnlineStatusCard extends React.Component {
    render() {
        return (
            <div>
               这是引入OnlineStatusCard组件后的内容，前端很好学
            </div>
        );
    }
}
