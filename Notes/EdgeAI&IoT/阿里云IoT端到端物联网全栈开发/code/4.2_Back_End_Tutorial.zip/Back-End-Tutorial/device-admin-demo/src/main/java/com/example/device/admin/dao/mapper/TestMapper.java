package com.example.device.admin.dao.mapper;


import com.example.device.admin.dao.entity.po.TestModel;
import tk.mybatis.mapper.common.BaseMapper;


public interface TestMapper extends BaseMapper<TestModel> {
}
