package com.example.device.admin.dao.mapper;

import com.example.device.admin.dao.entity.po.DevicePropHistoryLog;
import com.example.device.admin.dao.util.BaseMapper;


public interface DevicePropHistoryLogMapper extends BaseMapper<DevicePropHistoryLog> {

}