package com.example.device.admin.dao.mapper;



import com.example.device.admin.dao.entity.po.AlarmHistoryLog;
import com.example.device.admin.dao.util.BaseMapper;



public interface AlarmHistoryLogMapper extends BaseMapper<AlarmHistoryLog> {

}